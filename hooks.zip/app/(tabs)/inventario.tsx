import { Ativo, Inventario } from "@/types";
import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Button,
  Modal,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

import { useDataBase } from "@/database/DatabaseContext";
import { Picker } from "@react-native-picker/picker";

import EditModal from "@/components/EditModal";
import ListaAtivos from "@/components/ListaAtivos";
import { useCodigoInventario } from "@/contexts/CondigoInventarioContext";
import AntDesign from "@expo/vector-icons/AntDesign";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { Controller, SubmitHandler, useForm } from "react-hook-form";

import { useInventarios } from "@/contexts/InventariosContext";

import ModalLeitura from "@/components/ModalLeitura";
import { useBluetooth } from "@/contexts/BluetoothContext";

import DeleteModal from "@/components/DeleteModal";
import Segmented from "@/components/Segmented";
import { useAtivo } from "@/contexts/AtivosContext";
import { useLiveLocation } from "@/hooks/useLiveLocation";
import { codigoInventarioExiste } from "@/services/validacoes";
import { useFocusEffect } from "expo-router";

export type FormData = {
  codigo: string;
  descricao: string;
  dataHoraCriacao: string;
  dataHoraAtualizacao: string;
  centroDeCustos: string;
  subdivisao: string;
  aplica: number;
};

export type AtivoComEncontrado = Ativo & {
  Encontrado: number;
};

export default function TelaInventario() {
  const {
    control,
    watch,
    reset,
    handleSubmit,
    formState: { errors },
  } = useForm<FormData>();

  const db = useDataBase();

  const [selectedIndex, setSelectedIndex] = useState<number>(0);

  const [ativosLidos] = useState<number>(0);

  const [loading, setLoading] = useState<boolean>(false);

  const { inventarios, setInventarios } = useInventarios();

  const [modalState, setModalState] = useState<boolean>(false);
  const [addModal, setAddModal] = useState<boolean>(false);
  const [editModal, setEditModal] = useState<boolean>(false);
  const [deleteModalState, setDeleteModalState] = useState<boolean>(false);

  const [ativosInventario, setAtivosInventario] = useState<
    AtivoComEncontrado[]
  >([]);

  const { stopReading, dispositivoConectado, mensagensRef, debug, setDebug } = useBluetooth();

  const { location, error } = useLiveLocation();

  const [inventarioAtual, setInventarioAtual] = useState<number | null>(null);

  const { ativos } = useAtivo();

  const { codigo, setCodigo } = useCodigoInventario();

  const dataHora = new Date().toISOString();

  const onSubmit: SubmitHandler<FormData> = async (data) => {
    const inventario = await codigoInventarioExiste(watch("codigo"), db);

    if (inventario.length) {
      Alert.alert("Já existe um inventário com este código");
      return;
    }

    try {
      await db.execAsync(
        `INSERT INTO tbInventarios
          (codigo_inventario, descricao, status, dataHoraCriacao, dataHoraAtualizacao) VALUES (
          '${data.codigo}', 
          '${data.descricao}',
          '${0}', 
          '${dataHora}', 
          '${dataHora}');`,
      );
    } catch (err) {
      Alert.alert("Erro: " + String(err));
    }

    const result: Inventario[] = await db.getAllAsync(`
      SELECT * FROM tbInventarios;
      `);

    setInventarios(result);
    setInventarioAtual(result.length - 1);
  };

  const handlePicker = (index: number) => {
    if (index === -1) {
      setInventarioAtual(null);
      return;
    }

    const inventario = inventarios[index];

    if (!inventario) {
      console.warn("Inventário inválido:", index);
      return;
    }

    setInventarioAtual(index);
  };

  const inventarioId =
    inventarioAtual !== null ? inventarios[inventarioAtual].id : null;

  useFocusEffect(
    useCallback(() => {
      if (!editModal) {
        const buscarTodosAtivos = async () => {
          setLoading(true);
          setAtivosInventario([]);
          try {
            if (inventarioAtual === null) {
              return;
            }

            const rows: AtivoComEncontrado[] = await db.getAllAsync(`
          SELECT
          A.Encontrado,
          A.id,
          A.codigo_ativo,
          A.descricao,
          A.comentarios,
          A.categoria,
          A.localizacao,
          A.centroDeCustos ,
          A.subdivisao,
          A.dataHoraInventariado,
          A.status,
          A.dataHoraCriacao,
          A.dataHoraAtualizacao
        FROM
        (
          SELECT
          IIF(C.subdivisao IS NULL,0,1) AS Encontrado,
          A.id,
          A.codigo_ativo,
          A.descricao,
          A.comentarios,
          A.categoria,
          A.localizacao,
          A.centroDeCustos ,
          A.subdivisao,
          A.dataHoraInventariado,
          A.status,
          A.dataHoraCriacao,
          A.dataHoraAtualizacao
          FROM
          tbAtivos AS A
          INNER JOIN
          (
          SELECT
            inventario_id,
            centroDeCustos,
            subdivisao
          FROM
            tbCentrosInventarios
          WHERE
            inventario_id = '${inventarioId}'
          ) AS B
          ON
          (
          B.centroDeCustos = A.centroDeCustos AND
          B.subdivisao = A.subdivisao
          )
          LEFT JOIN
          tbAtivosInventario AS C
          ON
          (
          C.inventario_id = B.inventario_id AND
          C.codigo_ativo = A.codigo_ativo AND
          C.centroDeCustos = B.centroDeCustos AND
          C.subdivisao = B.subdivisao
          )
          UNION ALL
          SELECT
          2 AS Encontrado,
          A.id,
          A.codigo_ativo,
          A.descricao,
          A.comentarios,
          A.categoria,
          A.localizacao,
          A.centroDeCustos ,
          A.subdivisao,
          A.dataHoraInventariado,
          A.status,
          A.dataHoraCriacao,
          A.dataHoraAtualizacao
          FROM
          tbAtivos AS A
          LEFT JOIN
          (
          SELECT
            inventario_id,
            centroDeCustos,
            subdivisao
          FROM
            tbCentrosInventarios
          WHERE
            inventario_id = '${inventarioId}'
          ) AS B
          ON
          (
          B.centroDeCustos = A.centroDeCustos AND
          B.subdivisao = A.subdivisao
          )
          INNER JOIN
          tbAtivosInventario AS C
          ON
          (
          C.inventario_id = '${inventarioId}' AND
          C.codigo_ativo = A.codigo_ativo
          )
          WHERE
          B.inventario_id IS NULL
        ) AS A
          ORDER BY
          A.centroDeCustos,
          A.subdivisao,
          A.codigo_ativo;
        `);

            setAtivosInventario(rows);
          } catch (error) {
            console.error("Erro ao buscar ativos:", error);
          } finally {
            setLoading(false);
          }
        };

        buscarTodosAtivos();
      }
    }, [codigo, editModal, inventarioId]),
  );


  useEffect(() => {
    if (inventarioAtual === null || inventarioAtual === -1) {
      setCodigo("");
    } else {
      setCodigo(inventarios[inventarioAtual].codigo_inventario);
    }
  }, [inventarioAtual]);

  return (
    <View style={styles.container}>
      <ModalLeitura
        ativosLidos={ativosLidos}
        quantidadeAtivos={ativosInventario.length}
        modalState={modalState}
        setModalState={setModalState}
      />
      <View style={styles.toolbar}>
        {/* PICKER */}
        <View style={styles.pickerWrapper}>
          <Picker
            onValueChange={(value: number) => handlePicker(value)}
            style={styles.picker}
            selectedValue={inventarioAtual ?? undefined}
          >
            <Picker.Item label="Selecione um inventário" value={-1} />
            {inventarios?.map((i, index) => (
              <Picker.Item
                key={index}
                label={`${i.codigo_inventario} - ${i.descricao}`}
                value={index}
              />
            ))}
          </Picker>
        </View>

        {/* ADICIONAR */}
        <TouchableOpacity
          style={[styles.btn, styles.btnAdd]}
          onPress={() => setAddModal(true)}
        >
          <AntDesign name="plus" size={20} color="#fff" />
        </TouchableOpacity>

        {/* EDITAR */}
        {inventarioAtual !== null && (
          <TouchableOpacity
            style={[styles.btn, styles.btnEdit]}
            onPress={() => setEditModal(true)}
          >
            <AntDesign name="edit" size={20} color="#fff" />
          </TouchableOpacity>
        )}

        {/* Excluir */}
        {inventarioAtual !== null && (
          <TouchableOpacity
            onPress={() => setDeleteModalState(true)}
            style={[styles.btn, styles.btnDelete]}
          >
            <MaterialIcons name="delete" size={20} color="white" />
          </TouchableOpacity>
        )}

        {/* LEITURA */}
        {inventarioAtual !== null && (
          <TouchableOpacity
            style={[styles.btn, styles.btnRead]}
            onPress={() => {
              if (!dispositivoConectado) {
                Alert.alert("Nenhum dispositivo conectado.");
                return;
              }

              setModalState(true);
            }}
          >
            <AntDesign name="barcode" size={20} color="#fff" />
          </TouchableOpacity>
        )}
      </View>

      <Modal visible={addModal} transparent animationType="fade">
        <View style={styles.overlay}>
          <View style={styles.modal}>
            <Text style={{ marginBottom: 10, fontWeight: "bold" }}>
              Novo inventário
            </Text>
            <Controller
              control={control}
              name="codigo"
              rules={{ required: "O código é obrigatório" }}
              render={({
                field: { onChange, onBlur, value },
                fieldState: { error },
              }) => (
                <>
                  <TextInput
                    placeholder="Código"
                    style={[styles.input, error && styles.inputError]}
                    value={addModal ? value?.toString() : ""}
                    onChangeText={(text) => onChange(text)}
                    onBlur={onBlur}
                  />
                  {error && (
                    <Text style={styles.errorText}>{error.message}</Text>
                  )}
                </>
              )}
            />
            <Controller
              control={control}
              name="descricao"
              rules={{ required: "A descrição é obrigatória" }}
              render={({
                field: { onChange, onBlur, value },
                fieldState: { error },
              }) => (
                <>
                  <TextInput
                    placeholder="Descrição"
                    style={[styles.input, error && styles.inputError]}
                    value={value}
                    onChangeText={onChange}
                    onBlur={onBlur}
                  />
                  {error && (
                    <Text style={styles.errorText}>{error.message}</Text>
                  )}
                </>
              )}
            />

            <Button
              title="Criar"
              onPress={async () => {
                await handleSubmit(onSubmit)();
                setAddModal(false);
                reset();
              }}
            />

            <View
              style={{
                alignSelf: "flex-start",
                position: "absolute",
                right: 0,
              }}
            >
              <Button
                title="X"
                color="red"
                onPress={() => {
                  setAddModal(false);
                  reset();
                }}
              />
            </View>
          </View>
        </View>
      </Modal>

      {inventarioAtual !== null && (
        <EditModal
          editModal={editModal}
          setEditModal={setEditModal}
          inventarioAtual={inventarioAtual}
        />
      )}

      {inventarioAtual !== null && (
        <DeleteModal
          deleteModalState={deleteModalState}
          setDeleteModalState={setDeleteModalState}
          setInventarioAtual={setInventarioAtual}
          inventarioAtual={inventarioAtual}
        />
      )}

      {loading && <ActivityIndicator size={"large"} />}
      {!loading && (
        <View>
          {inventarioAtual !== null && (
            <Segmented
              selectedIndex={selectedIndex}
              setSelectedIndex={setSelectedIndex}
            />
          )}
          {inventarioAtual !== null && (
            <ListaAtivos
              ativos={ativosInventario}
              segmented={selectedIndex}
              loading={loading}
            />
          )}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    height: "100%",
  },
  textInput: {
    borderWidth: 1,
    borderColor: "gray",
    padding: 10,
    marginBottom: 8,
    width: "80%",
  },
  tableColums: {
    borderWidth: 1,
    borderColor: "gray",
    display: "flex",
    flexDirection: "row",
    gap: 10,
  },
  cell: {
    width: 120,
  },
  inventarioContainer: {
    borderWidth: 1,
    borderColor: "gray",
    display: "flex",
    flexDirection: "row",
    gap: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: "#999",
    borderRadius: 6,
    padding: 10,
    marginBottom: 15,
  },
  inputError: {
    borderColor: "red",
  },
  errorText: {
    color: "red",
    marginBottom: 10,
  },
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  modal: {
    width: "80%",
    padding: 20,
    backgroundColor: "white",
    borderRadius: 10,
  },
  toolbar: {
    flexDirection: "row",
    alignItems: "center",
    padding: 8,
    gap: 8,
  },

  /* PICKER */
  pickerWrapper: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 8,
    overflow: "hidden",
    backgroundColor: "#fff",
  },
  picker: {
    width: "100%",
  },

  /* BOTÕES */
  btn: {
    padding: 10,
    borderRadius: 10,
    elevation: 3,
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowRadius: 4,
    shadowOffset: { width: 1, height: 2 },
  },
  btnAdd: {
    backgroundColor: "#16a34a", // verde
  },
  btnEdit: {
    backgroundColor: "#2563eb", // azul
  },
  btnDelete: {
    backgroundColor: "red",
  },
  btnRead: {
    backgroundColor: "#7c3aed", // roxo
  },
});
