// import MapView, { Marker } from "react-native-maps";
import { useCodigoInventario } from "@/contexts/CondigoInventarioContext";
import { useInventarios } from "@/contexts/InventariosContext";
import { useDataBase } from "@/database/DatabaseContext";
import { AtivosInventario } from "@/types";
import { useEffect, useState } from "react";
import { ActivityIndicator, Text, View } from "react-native";

export default function Mapa() {
  const db = useDataBase();
  const { codigo } = useCodigoInventario();
  const { inventarios } = useInventarios();

  const [ativosInventario, setAtivosInventario] = useState<AtivosInventario[] | null>(null);

  const inventarioAtual = inventarios.find(
    (i) => i.codigo_inventario === codigo,
  );
  const inventarioId = inventarioAtual?.id;

  useEffect(() => {
    if (!inventarioId) {
      return;
    }
    (async () => {
      const rows: AtivosInventario[] = await db.getAllAsync(
        `
        SELECT * FROM tbAtivosInventarios WHERE inventario_id = '${inventarioId}';
        `,
      );
      setAtivosInventario(rows);
    })();
  }, []);

  if (!location) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1 }}>
      <Text>{JSON.stringify(location)}</Text>
      {/* <MapView
        style={{ flex: 1 }}
        initialRegion={{
          latitude: -23.55,
          longitude: -46.63,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        }}
      >
        <Marker
          coordinate={{
            latitude: -23.55,
            longitude: -46.63,
          }}
          title="Teste"
        />
      </MapView> */}
    </View>
  );
}
