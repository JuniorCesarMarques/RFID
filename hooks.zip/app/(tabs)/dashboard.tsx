import { useCodigoInventario } from "@/contexts/CondigoInventarioContext";
import { useInventarios } from "@/contexts/InventariosContext";
import { useDataBase } from "@/database/DatabaseContext";
import { useFocusEffect } from "expo-router";
import React, { useCallback, useState } from "react";
import { ScrollView, Text, View } from "react-native";

type Realizado = {
  Realizado: number;
  Total: number;
  centroDeCustos: string;
  subdivisao: string;
};

export default function Dashboard() {
  const db = useDataBase();
  const { codigo } = useCodigoInventario();
  const { inventarios } = useInventarios();

  const inventarioAtual = inventarios.find((i) => i.codigo_inventario === codigo);
  const inventarioId = inventarioAtual?.id;

  const [ativos, setAtivos] = useState<Realizado[]>([]);

  useFocusEffect(
    useCallback(() => {

      if (!db) return;
      const getAtivosInventarios = async () => {

        try {

          if(!inventarioAtual) return;
          console.log("Dashboard useFocus", inventarioAtual);

          const result: Realizado[] = await db.getAllAsync(`
            SELECT
              centroDeCustos,
              subdivisao,
              SUM(Total) AS Total,
              SUM(Realizado) AS Realizado
            FROM
            (
              SELECT DISTINCT
                B.centroDeCustos,
                B.subdivisao,
                A.codigo_ativo,
                1 AS Total,
                IIF(C.subdivisao IS NULL,0,1) AS Realizado
              FROM
                tbAtivos AS A
              INNER JOIN
              (
                SELECT
                  inventario_id,
                  centroDeCustos,
                  subdivisao
                FROM
                  tbCentrosInventarios
                WHERE
                  inventario_id = '${inventarioId}'
              ) AS B
              ON
              (
                B.centroDeCustos = A.centroDeCustos AND
                B.subdivisao = A.subdivisao
              )
              LEFT JOIN
                tbAtivosInventario AS C
              ON
              (
                C.inventario_id = B.inventario_id AND
                C.codigo_ativo = A.codigo_ativo AND
                C.centroDeCustos = A.centroDeCustos AND
                C.subdivisao = A.subdivisao
              )
            ) AS A
            GROUP BY
              centroDeCustos,
              subdivisao
            ORDER BY
              centroDeCustos, 
              subdivisao;
          `);

          setAtivos(result);

        } catch (error) {
          console.log("ERRO AO BUSCAR ATIVOS", error);
        }
      };

      getAtivosInventarios();
      return () => {};
    }, [db, inventarioId])
  );


  return (
    <View
      style={{
        borderColor: "#E5E5E5",
        borderWidth: 1,
        borderRadius: 10,
        padding: 10,
        backgroundColor: "#FAFAFA",
      }}
    >
      <Text style={{ textAlign: "center" }}>
        {inventarioAtual?.codigo_inventario} - {inventarioAtual?.descricao}
      </Text>

      <ScrollView>
        {ativos.map((a, index) => {
          const porcentagem = Number(((a?.Realizado * 100) / a?.Total).toFixed(1));
          return (
            <View
              key={index}
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 12,
                paddingVertical: 8,
                borderBottomWidth: index !== ativos.length - 1 ? 1 : 0,
                borderColor: "#E0E0E0",
              }}
            >
              {/* Centro/Subdivisão */}
              <View style={{ width: 110 }}>
                <Text
                  style={{ fontWeight: "600", fontSize: 14, color: "#333" }}
                >
                  {a?.centroDeCustos || "1500"}
                </Text>
                <Text style={{ color: "#555", fontSize: 12 }}>
                  {a?.subdivisao}
                </Text>
              </View>

              {/* Barra de Progresso */}
              <View style={{ flex: 1 }}>
                <View
                  style={{
                    backgroundColor: "#E0ECFF",
                    height: 18,
                    borderRadius: 6,
                    justifyContent: "center",
                    position: "relative",
                  }}
                >
                  <Text
                      style={{
                        fontSize: 10,
                        fontWeight: "600",
                        position: "absolute",
                        top: "50%",
                        left: "50%",
                        transform: [{ translateX: "-50%" }, { translateY: "-50%" }],
                        zIndex: 10
                      }}
                    >
                      {porcentagem}%
                    </Text>
                  <View
                    style={{
                      width: `${porcentagem}%`,
                      height: 18,
                      backgroundColor: "#4A90E2",
                      borderRadius: 6,
                      justifyContent: "center",
                    }}
                  >
            
                  </View>
                </View>
                <View style={{ display: "flex", alignItems: "center" }}>
                  <Text>
                    {a.Realizado}/{a.Total}
                  </Text>
                </View>
              </View>
            </View>
          );
        })}
      </ScrollView>
    </View>
  );
}
