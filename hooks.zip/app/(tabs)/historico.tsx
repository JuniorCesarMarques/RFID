import { useInventarios } from "@/contexts/InventariosContext";
import Entypo from "@expo/vector-icons/Entypo";

import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import * as XLSX from "xlsx";

import { useDataBase } from "@/database/DatabaseContext";
import { AtivosInventario } from "@/types";
import { Platform, ScrollView, StyleSheet, Text, View } from "react-native";

export default function Historico() {
  const { inventarios } = useInventarios();

  const db = useDataBase();

  const dateFormater = (index: number): string => {
    const date = new Date(inventarios[index].dataHoraAtualizacao);
    return `${date.getDate()}/${String(date.getMonth() + 1).padStart(2, "0")}/${date.getFullYear()}`;
  };

  const gerarXLSX = async (index: number): Promise<string> => {
    let historico: AtivosInventario[] = await db.getAllAsync(
      `SELECT
          A.codigo_inventario,
          B.descricao_ativo,
          B.comentarios_ativo,
          B.categoria_ativo,
          B.codigo_ativo,
          B.localizacao,
          B.centroDeCustos,
          B.subdivisao,
          B.dataHoraInventariado
      FROM
        tbInventarios AS A
      INNER JOIN
        tbAtivosInventario AS B
      ON
      (
        B.inventario_id = A.id
      )
      WHERE
        A.id = '${inventarios[index].id}';`
);


    const worksheet: XLSX.WorkSheet =
      XLSX.utils.json_to_sheet(historico);

    const workbook: XLSX.WorkBook = XLSX.utils.book_new();

    XLSX.utils.book_append_sheet(workbook, worksheet, "Dados");

    const base64: string = XLSX.write(workbook, {
      type: "base64",
      bookType: "xlsx",
    });

    const fileUri: string = FileSystem.documentDirectory + "historico.xlsx";

    await FileSystem.writeAsStringAsync(fileUri, base64, {
      encoding: FileSystem.EncodingType.Base64,
    });

    return fileUri;
  };

  const exportXLSX = async (index: number): Promise<void> => {
    const fileUri: string = await gerarXLSX(index);

    if (Platform.OS === "android") {
      const permissions =
        await FileSystem.StorageAccessFramework.requestDirectoryPermissionsAsync();

      if (!permissions.granted) return;

      const base64: string = await FileSystem.readAsStringAsync(fileUri, {
        encoding: FileSystem.EncodingType.Base64,
      });

      const uri: string =
        await FileSystem.StorageAccessFramework.createFileAsync(
          permissions.directoryUri,
          `historico-${inventarios[index].codigo_inventario}.xlsx`,
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        );

      await FileSystem.writeAsStringAsync(uri, base64, {
        encoding: FileSystem.EncodingType.Base64,
      });
    } else {
      await Sharing.shareAsync(fileUri);
    }
  };

  return (
    <ScrollView style={styles.container}>
      {inventarios.map((i, index) => (
        <View style={styles.card} key={index}>
          <View style={styles.item}>
            <View style={{ flexDirection: "row", gap: 5 }}>
              <Text style={styles.codigo}>{i.codigo_inventario}</Text>
              <Text>-</Text>
              <Text style={styles.descricao}>{i.descricao}</Text>
            </View>

            <Entypo onPress={() => {
              exportXLSX(index);
            }} name="export" size={22} color="#555" />
          </View>

          <Text>Última modificação: {dateFormater(index)}</Text>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 20,
    width: "100%",
    paddingHorizontal: 20,
    gap: 20,
  },
  card: {
    gap: 5,
    backgroundColor: "#f4f4f4",
    padding: 12,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#ddd",
  },
  item: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  codigo: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#333",
  },
  descricao: {
    fontSize: 14,
    color: "#555",
  },
});
