import {
  DarkTheme,
  DefaultTheme,
  ThemeProvider,
} from "@react-navigation/native";
import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import "react-native-reanimated";

import Header from "@/components/Header";
import AtivosProvider from "@/contexts/AtivosContext";
import BluetoothProvider from "@/contexts/BluetoothContext";
import CodigoInventarioProvider from "@/contexts/CondigoInventarioContext";
import InventariosProvider from "@/contexts/InventariosContext";
import DatabaseProvider from "@/database/DatabaseContext";
import { useColorScheme } from "@/hooks/use-color-scheme";

export const unstable_settings = {
  anchor: "(tabs)",
};

export default function RootLayout() {
  const colorScheme = useColorScheme();

  return (
    <BluetoothProvider>
      <DatabaseProvider>
        <InventariosProvider>
          <CodigoInventarioProvider>
            <AtivosProvider>
              <ThemeProvider
                value={colorScheme === "light" ? DefaultTheme : DarkTheme}
              >
                <Stack
                  screenOptions={{
                    header: () => <Header />,
                  }}
                >
                  <Stack.Screen name="(tabs)" options={{ headerShown: true }} />
                  <Stack.Screen
                    name="modal"
                    options={{ presentation: "modal", title: "Modal" }}
                  />
                </Stack>
                <StatusBar style="auto" />
              </ThemeProvider>
            </AtivosProvider>
          </CodigoInventarioProvider>
        </InventariosProvider>
      </DatabaseProvider>
    </BluetoothProvider>
  );
}
