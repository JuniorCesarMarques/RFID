import CarregarXML from "@/components/CarregarXml";
import { useAtivo } from "@/contexts/AtivosContext";
import { Ativo } from "@/types";
import { useEffect, useState } from "react";
import { ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { useDataBase } from "@/database/DatabaseContext";
import { Picker } from "@react-native-picker/picker";
import TodosAtivos from "@/components/TodosAtivos";
import { ActivityIndicator } from "@ant-design/react-native";

type selectedType = {
  selected: "codigo_ativo" | "descricao" | "centroDeCustos" | "subdivisao" | null;
};

export default function Ativos() {
  const { ativos, setAtivos } = useAtivo();

  const [selected, setSelected] = useState<selectedType["selected"]>(null);
  const [ loading, setLoading ] = useState<boolean>(false);

  const db = useDataBase();

  const [items] = useState([
    { label: "Código", value: "codigo_ativo" },
    { label: "Descrição", value: "descricao" },
  ]);

  const [ativosFiltrados, setAtivosFiltrados] = useState<Ativo[]>([]);

useEffect(() => {
  
  const getAtivos = async () => {
    try {
      setLoading(true);

      const rows: Ativo[] = await db.getAllAsync(
        "SELECT * FROM tbAtivos;"
      );

      setAtivos(rows);
      setAtivosFiltrados(rows);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  getAtivos();
}, []);

  useEffect(() => {
    setAtivosFiltrados(ativos);
  }, [ativos]);

  const handleFilter = (t: string) => {
    if (!selected) {
      setAtivosFiltrados(ativos);
      return;
    }

    const lowerCaseSeach = t.toLocaleLowerCase();

    const resultado = ativos.filter((a) =>
      a[selected].toLowerCase().includes(lowerCaseSeach)
    );

    setAtivosFiltrados(resultado);

  };

  return (
    <View style={styles.screen}>
      {/* Filtro */}
      <CarregarXML setLoading={setLoading} />
          {loading && <View style={{padding: 20}}>
            <ActivityIndicator size={"large"} />
          </View>}
          {!loading && <View>
            <View style={[styles.filterContainer, { zIndex: 10, elevation: 10 }]}>
              <View style={{ flex: 1, zIndex: 20 }}>
                <Picker
                  onValueChange={(value: selectedType["selected"]) =>
                    setSelected(value)
                  }
                >
                  <Picker.Item label="Filtrar por" value="" />
                  {items.map((i) => (
                    <Picker.Item label={i.label} value={i.value} />
                  ))}
                </Picker>
              </View>
              <TextInput
                onChangeText={handleFilter}
                style={styles.searchInput}
                placeholder="Buscar..."
                placeholderTextColor="#888"
              />
            </View>
            {/* Scroll horizontal para a tabela */}
            <ScrollView horizontal showsHorizontalScrollIndicator={true}>
              <View style={styles.container}>
                <View style={styles.rowHeader}>
                  <Text style={[styles.cellHeader, styles.cellCodigo]}>
                    Código
                  </Text>
                  <Text style={[styles.cellHeader, styles.cellDescricao]}>
                    Descrição
                  </Text>
                  <Text style={[styles.cellHeader, styles.cellCategoria]}>
                    Centro de custos
                  </Text>
                  <Text style={[styles.cellHeader, styles.cellSubdivisao]}>
                    Subdivisão
                  </Text>
                </View>
                <ScrollView showsVerticalScrollIndicator={true}>
                  {ativosFiltrados.map((ativo, index) => (
                    <TodosAtivos key={index} ativo={ativo} />
                  ))}
                </ScrollView>
              </View>
            </ScrollView>
          </View>}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#F9FAFB",
    padding: 16,
  },

  filterContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 20,
  },
  dropdown: {
    backgroundColor: "#fff",
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 8,
    height: 48,
  },
  dropdownContainer: {
    borderColor: "#ccc",
  },
  dropdownText: {
    fontSize: 16,
    color: "#333",
  },
  searchInput: {
    flex: 1,
    height: 48,
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    paddingHorizontal: 12,
    fontSize: 16,
    color: "#333",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },

  container: {
    backgroundColor: "#fff",
    borderRadius: 8,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  rowHeader: {
    flexDirection: "row",
    backgroundColor: "#f1f5f9",
    borderBottomWidth: 1,
    borderColor: "#e2e8f0",
    paddingVertical: 10,
    paddingHorizontal: 8,
    alignItems: "baseline",
  },
  cellHeader: {
    fontWeight: "600",
    fontSize: 14,
    color: "#334155",
    textAlign: "left",
    paddingHorizontal: 6,
  },
  cellCodigo: {
    width: 100,
  },
  cellDescricao: {
    width: 200,
  },
  cellCategoria: {
    width: 150,
  },
  cellSubdivisao: {
    width: 150,
  },
});
