export type Ativo = {
  codigo_ativo: string;
  descricao: string;
  comentarios: string;
  categoria: string;
  localizacao: string;
  centroDeCustos: string;
  subdivisao: string;
  dataHoraInventariado: string;
  status: number;
  dataHoraCriacao: string;
  dataHoraAtualizacao: string;
};

export type Inventario = {
  id: number;
  codigo_inventario: string;
  descricao: string;
  status: number;
  dataHoraInventariado: string;
  dataHoraCriacao: string;
  dataHoraAtualizacao: string;
};

export type CentrosInventariosType = {
  id: number;
  aplica: number;
  codigo: number;
  centroDeCustos: string;
  subdivisao: string;
};

export type AtivosInventario = {
  inventario_id: string;
  codigo_ativo: string;
  localizacao: string;
  centroDeCustos: string;
  subdivisao: string;
  dataHoraInventariado: string;
};
