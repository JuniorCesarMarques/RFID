import { AtivoComEncontrado } from "@/app/(tabs)/inventario";
import { StyleSheet, Text, View } from "react-native";

import FontAwesome from '@expo/vector-icons/FontAwesome';

export default function AtivoCard({ ativo }: { ativo: AtivoComEncontrado }) {
  return (
    <View style={styles.row}>
      <View style={[styles.cell, styles.wStatus]}>
        {ativo.Encontrado ? (<FontAwesome name="check-square" size={20} color="green" />) : <Text></Text>}
      </View>
      <Text style={[styles.cell, styles.wCodigo]}>{ativo.codigo_ativo}</Text>
      <Text style={[styles.cell, styles.wDescricao]}>{ativo.descricao}</Text>
      <Text style={[styles.cell, styles.wCategoria]}>
        {ativo.centroDeCustos}
      </Text>
      <Text style={[styles.cell, styles.wSubdivisao]}>{ativo.subdivisao}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: "row",
    borderBottomWidth: 1,
    borderColor: "#eee",
    paddingVertical: 8,
    paddingHorizontal: 8,
  },
  cell: {
    fontSize: 14,
    color: "#475569",
    paddingHorizontal: 6,
  },

  // LARGURAS FIXAS (IMPORTANTE: iguais ao ListaAtivos)
  wCodigo: { width: 100 },
  wStatus: { width: 100 },
  wDescricao: { width: 200 },
  wCategoria: { width: 150 },
  wSubdivisao: { width: 150 },
});
