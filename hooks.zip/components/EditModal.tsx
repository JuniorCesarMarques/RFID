// EditModal.tsx
import {
  Alert,
  Button,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

import Checkbox from "expo-checkbox";

import { useDataBase } from "@/database/DatabaseContext";
import { Inventario } from "@/types";
import { useEffect, useState } from "react";

import { useCodigoInventario } from "@/contexts/CondigoInventarioContext";
import { useInventarios } from "@/contexts/InventariosContext";
import { CentrosInventariosType } from "@/types";
import { Picker } from "@react-native-picker/picker";

type EditModalProps = {
  editModal: boolean;
  setEditModal: React.Dispatch<React.SetStateAction<boolean>>;
  inventarioAtual: number;
};

// Tipo temporario
type LocalsType = {
  aplica: number;
  centroDeCustos: string;
  subdivisao: string;
};

type EditFormData = {
  codigo: string;
  descricao: string;
  lista: LocalsType[];
};

type StatusType = {
  label: string;
  value: string;
};

export default function EditModal({
  editModal,
  setEditModal,
  inventarioAtual,
}: EditModalProps) {
  const db = useDataBase();

  const dataHora = new Date().toISOString();

  const { inventarios, setInventarios } = useInventarios();

  const [locals, setLocals] = useState<LocalsType[]>([]);

  const { codigo } = useCodigoInventario();

  const status: StatusType[] = [
    {
      label: "Pendente",
      value: "pendente",
    },
    {
      label: "Em andamento",
      value: "andamento",
    },
    {
      label: "Cancelado",
      value: "cancelado",
    },
    {
      label: "Finalizado",
      value: "finalizado",
    },
  ];

  // Formulário de edição
  const [inventForm, setInventForm] = useState<EditFormData>({
    codigo: codigo,
    descricao: inventarios[inventarioAtual].descricao,
    lista: [],
  });


  const editarInventario = async () => {

    const outrosInventarios = inventarios.filter(
      (i) => i.codigo_inventario !== inventarios[inventarioAtual].codigo_inventario,
    );

    const codigoExiste = outrosInventarios.some(
      (i) => i.codigo_inventario === inventForm.codigo,
    );

    if (codigoExiste) {
      Alert.alert("Este código já existe.");
      return;
    }

    await db.execAsync(
      `UPDATE tbInventarios SET
       codigo_inventario = '${inventForm.codigo}',
       descricao = '${inventForm.descricao}',
       dataHoraAtualizacao = '${dataHora}'
     WHERE id = ${inventarios[inventarioAtual].id};`,
    );

    const result: Inventario[] = await db.getAllAsync(
      "SELECT * FROM tbInventarios;",
    );

    await handleInsertLocals();
    setInventarios(result);
  };

  // Busca todos os inventários
  useEffect(() => {
    const getInventarios = async () => {
      if (inventarioAtual === null) {
        return;
      }

      const result: LocalsType[] = await db.getAllAsync(`
      SELECT DISTINCT
        IIF(B.inventario_id IS NULL,0,1) AS aplica,
        A.centroDeCustos,
        A.subdivisao
      FROM
        tbAtivos AS A
      LEFT JOIN
      (
        SELECT
          inventario_id,
          centroDeCustos,
          subdivisao
        FROM
          tbCentrosInventarios
        WHERE
          inventario_id = '${inventarios[inventarioAtual].id}'
      ) AS B
      ON
      (
        B.centroDeCustos = A.centroDeCustos AND
        B.subdivisao = A.subdivisao
      )
      ORDER BY
        A.centroDeCustos, 
        A.subdivisao;
    `);

      setLocals(result);
    };
    getInventarios();
  }, [editModal]);

  const handleInventForm = (value: string, name: string, index?: number) => {
    if (name === "codigo") {
      setInventForm((prev) => ({
        ...prev,
        codigo: value,
      }));
    }

    if (name === "descricao") {
      setInventForm((prev) => ({
        ...prev,
        descricao: value as string,
      }));

    }
  };

  const handleInsertLocals = async () => {
    const locaisAplicaveis = locals.filter((l) => l.aplica);

    // checa se pelo menos um centro foi selecionado
    if (locaisAplicaveis) {
      const existing: CentrosInventariosType | null = await db.getFirstAsync(`
          SELECT * FROM tbCentrosInventarios WHERE inventario_id = '${inventarios[inventarioAtual].id}'
          `);

      // Caso não tenha nenhum centroInventario com esse codigo
      if (!existing) {
        for (const c of locaisAplicaveis) {
          await db.execAsync(`
      INSERT INTO tbCentrosInventarios
      (inventario_id, centroDeCustos, subdivisao) VALUES ('${inventarios[inventarioAtual].id}', '${c.centroDeCustos}', '${c.subdivisao}')
      `);
        }
      } else {
        await db.execAsync(`
      DELETE FROM tbCentrosInventarios WHERE inventario_id = '${inventarios[inventarioAtual].id}'
      `);
        for (const c of locaisAplicaveis) {
          await db.execAsync(`
      INSERT INTO tbCentrosInventarios
      (inventario_id, centroDeCustos, subdivisao) VALUES ('${inventarios[inventarioAtual].id}', '${c.centroDeCustos}', '${c.subdivisao}')
      `);
        }
      }
    }
  };

  // revisar
  useEffect(() => {
    setInventForm({
      codigo: codigo,
      descricao: inventarios[inventarioAtual].descricao,
      lista: [],
    });
  }, [editModal]);

  return (
    <Modal
      visible={editModal}
      transparent
      animationType="fade"
      onRequestClose={() => setEditModal(false)}
    >
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <Text style={{ marginBottom: 10, fontWeight: "bold" }}>
            Editar inventário
          </Text>

          <TextInput
            placeholder="Código"
            style={[styles.input, styles.inputError]}
            defaultValue={inventarios[inventarioAtual].codigo_inventario.toString()}
            onChangeText={(text) => handleInventForm(text, "codigo")}
          />

          <TextInput
            placeholder="Descrição"
            style={[styles.input, styles.inputError]}
            defaultValue={inventarios[inventarioAtual].descricao}
            onChangeText={(text) => handleInventForm(text, "descricao")}
          />

          <Picker onValueChange={() => ""}>
            <Picker.Item label="Status" value={null} />
            {status.map((s) => (
              <Picker.Item label={`${s.label}`} value={`${s.value}`} />
            ))}
          </Picker>

          {/* Scroll SOMENTE na parte da tabela */}
          <ScrollView
            style={{ maxHeight: 300 }}
            showsVerticalScrollIndicator={true}
          >
            <ScrollView
              horizontal
              contentContainerStyle={{ padding: 10 }}
              showsHorizontalScrollIndicator={true}
            >
              <View
                style={{
                  borderWidth: 1,
                  borderColor: "#ccc",
                  borderRadius: 4,
                  overflow: "hidden",
                }}
              >
                {/* Cabeçalho */}
                <View
                  style={{
                    flexDirection: "row",
                    backgroundColor: "#f2f2f2",
                    borderBottomWidth: 1,
                    borderColor: "#ccc",
                    paddingVertical: 8,
                    alignItems: "center",
                  }}
                >
                  <Text
                    style={{
                      width: 70,
                      fontWeight: "bold",
                      textAlign: "center",
                    }}
                  >
                    Aplica
                  </Text>
                  <Text
                    style={{ width: 160, fontWeight: "bold", paddingLeft: 8 }}
                  >
                    Centro de custos
                  </Text>
                  <Text
                    style={{ width: 160, fontWeight: "bold", paddingLeft: 8 }}
                  >
                    Subdivisão
                  </Text>
                </View>

                {/* Linhas */}
                {locals.map((l, i) => (
                  <View
                    key={i}
                    style={{
                      flexDirection: "row",
                      borderBottomWidth: 1,
                      borderColor: "#eee",
                      paddingVertical: 8,
                      alignItems: "center",
                    }}
                  >
                    <View
                      style={{
                        width: 70,
                        justifyContent: "center",
                        alignItems: "center",
                      }}
                    >
                      <Checkbox
                        value={locals[i].aplica === 1}
                        onValueChange={(value) => {
                          const updated = locals.map((item, index) =>
                            index === i
                              ? { ...item, aplica: value ? 1 : 0 }
                              : item,
                          );
                          setLocals(updated);
                        }}
                      />
                    </View>
                    <Text style={{ width: 160, paddingLeft: 8 }}>
                      {l.centroDeCustos}
                    </Text>
                    <Text style={{ width: 160, paddingLeft: 8 }}>
                      {l.subdivisao}
                    </Text>
                  </View>
                ))}
              </View>
            </ScrollView>
          </ScrollView>

          <Button
            title="Salvar"
            onPress={async () => {
              await editarInventario();
              setEditModal(false);
            }}
          />

          <View
            style={{
              position: "absolute",
              right: 0,
              top: 0,
            }}
          >
            <Button title="X" color="red" onPress={() => setEditModal(false)} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  input: {
    borderWidth: 1,
    borderColor: "#999",
    borderRadius: 6,
    padding: 10,
    marginBottom: 15,
  },
  inputError: {
    borderColor: "red",
  },
  errorText: {
    color: "red",
    marginBottom: 10,
  },
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  modal: {
    width: "80%",
    padding: 20,
    backgroundColor: "white",
    borderRadius: 10,
  },
});
