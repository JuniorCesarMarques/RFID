import * as DocumentPicker from "expo-document-picker";
import { XMLParser } from "fast-xml-parser";
import { SetStateAction } from "react";
import { Button, View } from "react-native";

import { useAtivo } from "@/contexts/AtivosContext";
import { useDataBase } from "@/database/DatabaseContext";
import { Ativo } from "@/types";

export default function CarregarXML({
  setLoading
}: {
  setLoading: React.Dispatch<SetStateAction<boolean>>;
}) {
  const { setAtivos } = useAtivo();
  const db = useDataBase();

  const pickXML = async () => {
    setLoading(true);
    const result = await DocumentPicker.getDocumentAsync({
      type: "text/xml",
      copyToCacheDirectory: true,
    });

    if ("canceled" in result && result.canceled) return;

    const file = result.assets[0];
    const response = await fetch(file.uri);
    const text = await response.text();

    // Parse do XML
    const parser = new XMLParser();
    const json = parser.parse(text);

    const ativos = json.ativos.ativo;

    await db.execAsync("DELETE FROM tbAtivos;");

    await db.getAllAsync("PRAGMA table_info(tbAtivos);");

    for (const a of ativos) {
      await db.execAsync(
        `INSERT INTO tbAtivos 
          (codigo_ativo, descricao, comentarios, categoria, localizacao, centroDeCustos, subdivisao, dataHoraInventariado, status, dataHoraCriacao, dataHoraAtualizacao) 
         VALUES ('${a.codigo_ativo}', '${a.descricao}', '${a.comentarios}', '${a.categoria}', '${a.localizacao}', '${a.centroDeCustos}', '${a.subdivisao}', '${a.dataHoraInventariado}', '${a.status}', '${a.dataHoraCriacao}', '${a.dataHoraAtualizacao}');`,
      );
    }

    const rows: Ativo[] = await db.getAllAsync("SELECT * FROM tbAtivos;");

    setLoading(false);
    setAtivos(rows);
  };

  return (
    <View style={{ width: 150 }}>
      <Button title="Carregar XML" onPress={pickXML} />
    </View>
  );
}
