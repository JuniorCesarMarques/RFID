import SegmentedControl from '@react-native-segmented-control/segmented-control';
import { SetStateAction } from 'react';

type SegmentedType = {
    selectedIndex: number;
    setSelectedIndex: React.Dispatch<SetStateAction<number>>
}

export default function Segmented({selectedIndex, setSelectedIndex}: SegmentedType) {

    return (
  <SegmentedControl
    values={['Todos', 'Lidos', 'Pendentes', 'Extras']}
    selectedIndex={selectedIndex}
    onChange={(event) => {
      setSelectedIndex(event.nativeEvent.selectedSegmentIndex);
    }}
  />
);
}

