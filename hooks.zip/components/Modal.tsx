// import { Controller, useForm } from "react-hook-form";
// import { Button, Modal, StyleSheet, Text, TextInput, View } from "react-native";

// type ModalProps = {
//   onClose: (v: boolean) => void;
//   onVisible: (v: boolean) => void;
//   visible: boolean;
//   FormData: {
//     codigo: string;
//     descricao: string;
//     dataHoraCriacao: string;
//     dataHoraAtualizacao: string;
//   };
//   children: React.ReactNode;
// };



// const ModalComponent = ({
//   children,
//   onClose,
//   visible,
//   onVisible,
//   FormData,
// }: ModalProps) => {
//   const {
//     control,
//     handleSubmit,
//     formState: { errors },
//   } = useForm();

//   return (
//     <Modal
//       visible={visible}
//       transparent
//       animationType="fade"
//       onRequestClose={() => onVisible(false)}
//     >
//       <View style={styles.overlay}>
//         <View style={styles.modal}>
//           <Text style={{ marginBottom: 10, fontWeight: "bold" }}>
//             Novo inventário
//           </Text>
//           <Controller
//             control={control}
//             name="codigo"
//             rules={{ required: "O código é obrigatório" }}
//             render={({
//               field: { onChange, onBlur, value },
//               fieldState: { error },
//             }) => (
//               <>
//                 <TextInput
//                   placeholder="Código"
//                   style={[styles.input, error && styles.inputError]}
//                   value={value}
//                   onChangeText={onChange}
//                   onBlur={onBlur}
//                 />
//                 {error && <Text style={styles.errorText}>{error.message}</Text>}
//               </>
//             )}
//           />
//           <Controller
//             control={control}
//             name="descricao"
//             rules={{ required: "A descrição é obrigatória" }}
//             render={({
//               field: { onChange, onBlur, value },
//               fieldState: { error },
//             }) => (
//               <>
//                 <TextInput
//                   placeholder="Descrição"
//                   style={[styles.input, error && styles.inputError]}
//                   value={value}
//                   onChangeText={onChange}
//                   onBlur={onBlur}
//                 />
//                 {error && <Text style={styles.errorText}>{error.message}</Text>}
//               </>
//             )}
//           />

//           <Button
//             title="Criar"
//             onPress={() => {
//               handleSubmit(onSubmit)();
//               onVisible(false);
//             }}
//           />

//           <View
//             style={{
//               alignSelf: "flex-start",
//               position: "absolute",
//               right: 0,
//             }}
//           >
//             <Button
//               title="X"
//               color="red"
//               onPress={() => {
//                 onVisible(false);
//               }}
//             />
//           </View>
//         </View>
//       </View>
//     </Modal>
//   );
// };

// export default Modal;

// const styles = StyleSheet.create({
//   overlay: {
//     flex: 1,
//     backgroundColor: "rgba(0,0,0,0.5)",
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   modal: {
//     width: "80%",
//     padding: 20,
//     backgroundColor: "white",
//     borderRadius: 10,
//   },
//   input: {
//     borderWidth: 1,
//     borderColor: "#999",
//     borderRadius: 6,
//     padding: 10,
//     marginBottom: 15,
//   },
//   inputError: {
//     borderColor: "red",
//   },
//   errorText: {
//     color: "red",
//     marginBottom: 10,
//   },
// });
