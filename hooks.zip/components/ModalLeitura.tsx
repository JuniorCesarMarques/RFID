import { useBluetooth } from "@/contexts/BluetoothContext";
import { useFocusEffect } from "@react-navigation/native";
import { Dispatch, useCallback } from "react";
import { Modal, StyleSheet, Text, TouchableOpacity, View } from "react-native";

type ModalLeituraType = {
  ativosLidos: number;
  quantidadeAtivos: number;
  modalState: boolean;
  setModalState: Dispatch<React.SetStateAction<boolean>>;
};


export default function ModalLeitura({
  ativosLidos,
  modalState,
  setModalState,
  quantidadeAtivos,
}: ModalLeituraType) {

  const { count, startReading, debug } = useBluetooth();

useFocusEffect(
  useCallback(() => {
    if(modalState) {
      startReading();
    }

  }, [modalState])
);

  return (
    <Modal
      visible={modalState}
      transparent
      animationType="fade"
      onRequestClose={() => setModalState(false)}
    >
      <View style={styles.modalContainer}>
        <View style={styles.modal}>
          <TouchableOpacity
            onPress={() => setModalState(false)}
            style={styles.closeButton}
          >
            <Text style={{ color: "white", fontWeight: "bold", flex: 1 }}>X</Text>
          </TouchableOpacity>

          <View style={{alignItems: "center", justifyContent: "center", height: "100%"}}>
              <Text>Debug: {debug}</Text>
              <Text style={styles.TextoLeitura}>Modo Leitura...</Text>
              <Text style={styles.TextoLeitura}>{count}</Text>
              <Text style={styles.TextoLeitura}>{ativosLidos + "/" + quantidadeAtivos}</Text>
          </View>
        </View>
      </View>
    </Modal>
  );
}


const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    alignItems: "center",
    justifyContent: "center",
  },
  modal: {
    width: "90%",
    height: "50%",
    backgroundColor: "white",
    borderRadius: 12,
    position: "relative",
  },
  closeButton: {
    position: "absolute",
    right: 10,
    top: 10,
    backgroundColor: "red",
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  TextoLeitura: {
    fontSize: 35
  }
});