import { Image, Text, View, StyleSheet } from "react-native";

export default function Header() {
  return (
    <View
      style={styles.container}
    >
      <Image source={require("@/assets/images/logo-bmi.jpg")} />
      <Text style={styles.text}>Inventário de ativos</Text>
      <View style={{flex: 1}}></View>
    </View>
  );
}

const styles = StyleSheet.create({
    container: {
        paddingTop: 25,
        paddingBottom: 5,
        paddingHorizontal: 5,
        backgroundColor: "white",
        display: "flex",
        flexDirection: "row",
        gap: 2,
        justifyContent: "space-between",
        alignItems: "center",
        borderBottomWidth: 1
    },
    text: {
        fontSize: 20
    }
})