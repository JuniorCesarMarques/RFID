import { AtivoComEncontrado } from "@/app/(tabs)/inventario";
import { ScrollView, StyleSheet, View } from "react-native";
import AtivoCard from "./AtivoCard";
import HeaderAtivos from "./HeaderAtivos";

export default function ListaAtivos({
  ativos,
  segmented,
  loading,
}: {
  ativos: AtivoComEncontrado[];
  segmented: number;
  loading: boolean;
}) {
  let conteudo;

  switch (segmented) {
    case 0:
      conteudo = ativos.map((a, index) => <AtivoCard key={index} ativo={a} />);
      break;
    case 1:
      conteudo = ativos
        .filter((a) => a.Encontrado === 1)
        .map((a, index) => <AtivoCard key={index} ativo={a} />);
      break;
    case 2:
      conteudo = ativos
        .filter((a) => a.Encontrado === 0)
        .map((a, index) => <AtivoCard key={index} ativo={a} />);
      break;
    case 3:
    conteudo = ativos
      .filter((a) => a.Encontrado === 2)
      .map((a, index) => <AtivoCard key={index} ativo={a} />);
    break;
  }


  return (
    <ScrollView
      horizontal
      contentContainerStyle={{
        padding: 10,
      }}
    >
      <View style={styles.container}>
        <HeaderAtivos />
        <View>
          <ScrollView>{conteudo}</ScrollView>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#fff",
    borderRadius: 8,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
    paddingBottom: 20,
  },

  /* HEADER */

  cellHeader: {
    fontWeight: "600",
    fontSize: 14,
    color: "#334155",
    textAlign: "left",
    paddingHorizontal: 6,
  },

  // LARGURAS FIXAS (devem ser copiadas para o Card)
});
