import React, { createContext, SetStateAction, useContext, useRef, useState } from "react";
import { Alert } from "react-native";
import { PermissionsAndroid, Platform } from "react-native";
import BluetoothClassic, {
  BluetoothDevice,
  BluetoothEventSubscription,
} from "react-native-bluetooth-classic";
import BluetoothModule from "react-native-bluetooth-classic/lib/BluetoothModule";

type BluetoothContextType = {
  BluetoothClassic: BluetoothModule;
  startReading: () => void;
  stopReading: () => void;
  count: number;
  mensagensRef: React.RefObject<string[]>;
  dispositivoConectado: BluetoothDevice | null;
  connect: (device: BluetoothDevice, leitura: () => void) => Promise<void>;
  disconnect: () => Promise<void>;
  debug: string;
  setDebug: React.Dispatch<SetStateAction<string>>;
};

const BluetoothContext = createContext<BluetoothContextType | null>(null);

export default function BluetoothProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [dispositivoConectado, setDispositivoConectado] =
    useState<BluetoothDevice | null>(null);

  const mensagensRef = useRef<string[]>([]);

  const [count, setCount] = useState<number>(0);

  const [debug, setDebug] = useState<string>("");

  const subscriptionRef = useRef<BluetoothEventSubscription | null>(null);
  const lendoRef = useRef<boolean>(false);

  function startReading() {
    mensagensRef.current = [];
    setCount(0);
    lendoRef.current = true;
  }

  function stopReading() {
    lendoRef.current = false;
  }


  async function ensureBluetoothPermissions() {
  if (Platform.OS !== "android") return true;

  const permissions = [PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION];

  if (Platform.Version >= 31) {
    permissions.push(
      PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
      PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT
    );
  }

  const granted = await PermissionsAndroid.requestMultiple(permissions);

  return Object.values(granted).every(
    (v) => v === PermissionsAndroid.RESULTS.GRANTED
  );
}

  async function connect(device: BluetoothDevice, callback: () => void) {

  const ok = await ensureBluetoothPermissions();

  if (!ok) {
    Alert.alert("Permissões de Bluetooth não concedidas");
    return;
  }

    try {
      const connected = await BluetoothClassic.connectToDevice(device.address);

      setDispositivoConectado(connected);

      subscriptionRef.current?.remove();

      setDebug("Dispositivo conectado: " + connected?.name);
      subscriptionRef.current = BluetoothClassic.onDeviceRead(
        connected.address,
        (event) => {

          setDebug("Callback do listener");
          if (!lendoRef.current) return;

          setDebug("Passou do lendoref");
          setCount((prev) => prev + 1);
          startReading();
          mensagensRef.current.push(event.data);

          callback();
        }
      );

      setDebug("Listener criado");
    } catch (e) {
      Alert.alert("Erro ao conectar");
    }
  }

  /** Desconectar */
  async function disconnect() {
    if (!dispositivoConectado) return;

    try {

      stopReading();

      subscriptionRef.current?.remove();
      subscriptionRef.current = null;

      await BluetoothClassic.disconnectFromDevice(dispositivoConectado.address);

      setDispositivoConectado(null);
      mensagensRef.current = [];
      setCount(0);
    } catch (e) {
      Alert.alert("Erro ao desconectar");
    }
  }

  return (
    <BluetoothContext.Provider
      value={{
        connect,
        disconnect,
        dispositivoConectado,
        mensagensRef,
        count,
        startReading,
        stopReading,
        BluetoothClassic,
        debug,
        setDebug
      }}
    >
      {children}
    </BluetoothContext.Provider>
  );
}

export const useBluetooth = () => {
  const context = useContext(BluetoothContext);

  if (!context)
    throw new Error(
      "useBluetooth deve ser usado dentro de um BluetoothProvider"
    );

  return context;
};
