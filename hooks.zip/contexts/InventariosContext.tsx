import { Inventario } from "@/types";
import {
  createContext,
  Dispatch,
  useContext,
  useEffect,
  useState,
} from "react";

import { useDataBase } from "@/database/DatabaseContext";

type InventariosContextType = {
  inventarios: Inventario[];
  setInventarios: Dispatch<React.SetStateAction<Inventario[]>>;
};

const InventariosContext = createContext<InventariosContextType | null>(null);

export default function InventariosProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const db = useDataBase();

  const [inventarios, setInventarios] = useState<Inventario[]>([]);

  useEffect(() => {
    const getInventarios = async () => {
      const res: Inventario[] = await db.getAllAsync(`
          SELECT * FROM tbInventarios;
          `);

      setInventarios(res);
    };
    getInventarios();
  }, []);

  return (
    <InventariosContext.Provider value={{ inventarios, setInventarios }}>
      {children}
    </InventariosContext.Provider>
  );
}

export const useInventarios = () => {
  const context = useContext(InventariosContext);
  if (!context) {
    throw new Error(
      "useInventarios deve ser usado dentro de IventariosProvider"
    );
  }
  return context;
};
