import { Ativo } from "@/types";
import React, { useContext, createContext, useState, Dispatch } from "react";

interface AtivosContextProps {
  ativos: Ativo[];
  setAtivos: Dispatch<React.SetStateAction<Ativo[]>>
  addAtivo: (novoAtivo: Ativo) => void;
  removeAtivo: (codigo_rfid: string) => void;
}

const AtivosContext = createContext<AtivosContextProps>({
    ativos: [],
    setAtivos: () => [],
    addAtivo: () => [],
    removeAtivo: () => []
})

export default function AtivosProvider({ children }: { children: React.ReactNode }){

    const [ativos, setAtivos] = useState<Ativo[]>([]);

    const addAtivo = (novoAtivo: Ativo) => {
        setAtivos(prev => [...prev, novoAtivo]);
    }

    const removeAtivo = (codigo_rfid: string) => {
        setAtivos(prev => prev.filter(a => a.codigo !== codigo_rfid));
    }

    return(
        <AtivosContext.Provider value={{ativos, addAtivo, removeAtivo, setAtivos}}>
            {children}
        </AtivosContext.Provider>
    )
}

export const useAtivo = () => {
    const context = useContext(AtivosContext);

    if(!context) {
        throw new Error("useAtivo deve ser usado dentro de um AtivosProvider");
    }
    return context;
}