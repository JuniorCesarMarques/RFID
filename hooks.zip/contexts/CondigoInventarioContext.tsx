import { createContext, Dispatch, useContext, useState } from "react";

type CodigoInventarioContext = {
    codigo: string,
    setCodigo: Dispatch<React.SetStateAction<string>>
}

const CodigoInventarioContext = createContext<CodigoInventarioContext | null>(null);


export default function CodigoInventarioProvider({children}: {children: React.ReactNode}) {

    const [codigo, setCodigo] = useState<string>("");

    return (
        <CodigoInventarioContext.Provider value={{codigo, setCodigo}}>
                {children}
        </CodigoInventarioContext.Provider>
    )
}

export const useCodigoInventario = () => {
    const context = useContext(CodigoInventarioContext);

    if(!context) {
        throw new Error("useAtivo deve ser usado dentro de um CodigoInventarioProvider");
    }

    return context;
}

