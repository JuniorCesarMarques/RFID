import { useAtivo } from "@/contexts/AtivosContext";
import { useBluetooth } from "@/contexts/BluetoothContext";
import { useCodigoInventario } from "@/contexts/CondigoInventarioContext";
import { useInventarios } from "@/contexts/InventariosContext";
import { useDataBase } from "@/database/DatabaseContext";
import { useLiveLocation } from "@/hooks/useLiveLocation";
import { Alert } from "react-native";

export default function useLeitura() {
  const { dispositivoConectado, mensagensRef, stopReading, setDebug } = useBluetooth();
  const { inventarios } = useInventarios();
  const { location } = useLiveLocation();
  const { ativos } = useAtivo();
  const db = useDataBase();
  const { codigo } = useCodigoInventario();


  const inventarioAtual = inventarios.find(
    (i) => i.codigo_inventario === codigo,
  );

  const leitura = async () => {
    setDebug("Função de leitura");
    if (!dispositivoConectado) {
      Alert.alert(
        "Bluetooth desconectado",
        "Conecte o leitor antes de iniciar a leitura.",
      );
      return;
    }

    if (!inventarioAtual) {
      Alert.alert(
        "Inventário não selecionado",
        "Selecione um inventário para continuar.",
      );
      return;
    }

    if (!inventarios) {
      Alert.alert("Inventário invalido");
      return;
    }

    // Impede undefined ou erro
    if (!location) {
      Alert.alert("Localização ainda não carregada ou houve erro.");
      return;
    }

    setDebug("Passou pelas validações");

    const { latitude, longitude, accuracy } = location.coords;
    const timestamp = location.timestamp;

    const localizacao = `${latitude},${longitude},${accuracy},${timestamp}`;

    const ativosLidos = mensagensRef.current
      .filter((m) => m.includes("EP:"))
      .map((c) => {
        let codigo = c.split(": ")[1].trim().replace(/^0+/, "");

        let i = ativos.find((a) => a.codigo_ativo === codigo);

        return {
          localizacao,
          codigo_ativo: codigo,
          inventario_id: inventarioAtual.id,
          descricao_ativo: i?.descricao ?? "",
          comentarios_ativo: i?.comentarios ?? "",
          categoria_ativo: i?.categoria ?? "",
          centroDeCustos: i?.centroDeCustos ?? "",
          subdivisao: i?.subdivisao ?? "",
          dataHoraInventariado: i?.dataHoraInventariado ?? "",
        };
      });

    try {
      for (let ativo of ativosLidos) {
        await db.execAsync(`
          INSERT INTO tbAtivosInventario (inventario_id, codigo_ativo, descricao_ativo, comentarios_ativo, categoria_ativo, inputType, localizacao, centroDeCustos, subdivisao, dataHoraInventariado)
    VALUES ('${ativo.inventario_id}', '${ativo.codigo_ativo}', '${ativo.descricao_ativo}', '${ativo.comentarios_ativo}', '${ativo.categoria_ativo}', 0, '${ativo.localizacao}', '${ativo.centroDeCustos}', '${ativo.subdivisao}', '${ativo.dataHoraInventariado}')
    ON CONFLICT(inventario_id, codigo_ativo) DO UPDATE SET
        localizacao = excluded.localizacao,
      centroDeCustos = excluded.centroDeCustos,
      subdivisao = excluded.subdivisao,
      dataHoraInventariado = excluded.dataHoraInventariado;
      `);
      }
      setDebug("Ativo inserido ao banco");
      stopReading();
    } catch (err) {}
  };

  return { leitura };
}
