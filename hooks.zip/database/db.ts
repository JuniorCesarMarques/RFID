import * as SQLite from "expo-sqlite";
import { createTableAtivos } from "./tables/ativos";
import { createTableInventarios } from "./tables/inventatios";
import { createTableCentrosInventarios } from "./tables/centrosInventarios";
import { createTableAtivosInventario } from "./tables/ativosInventario";

export const initDb = async () => {
  const db = await SQLite.openDatabaseAsync("db_inventario_ativos");

  await createTableAtivos(db);
  await createTableInventarios(db);
  await createTableCentrosInventarios(db);
  await createTableAtivosInventario(db);

  return db;
};



