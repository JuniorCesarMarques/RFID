export const createTableCentrosInventarios = async (db: any) => {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS tbCentrosInventarios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      inventario_id INTEGER,
      centroDeCustos TEXT,
      subdivisao TEXT
    );
  `);
};