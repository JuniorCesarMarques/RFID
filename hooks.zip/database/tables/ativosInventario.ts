export const createTableAtivosInventario = async (db: any) => {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS tbAtivosInventario (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    inventario_id INTEGER,
    codigo_ativo TEXT NOT NULL,
    descricao_ativo TEXT,
    comentarios_ativo TEXT,
    categoria_ativo TEXT,
    inputType INTEGER,
    localizacao TEXT,
    centroDeCustos TEXT,
    subdivisao TEXT,
    dataHoraInventariado TEXT,
    UNIQUE (inventario_id, codigo_ativo)
    );`);
};
