export const createTableInventarios = async (db: any) => {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS tbInventarios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      codigo_inventario TEXT NOT NULL,
      descricao TEXT,
      status INTEGER,
      dataHoraCriacao TEXT,
      dataHoraAtualizacao TEXT
    );
  `);
};
