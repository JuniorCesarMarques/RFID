export const createTableAtivos = async (db: any) => {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS tbAtivos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      codigo_ativo TEXT NOT NULL,
      descricao TEXT,
      comentarios TEXT,
      categoria TEXT,
      localizacao TEXT,
      centroDeCustos TEXT,
      subdivisao TEXT,
      dataHoraInventariado TEXT,
      status INTEGER,
      dataHoraCriacao TEXT,
      dataHoraAtualizacao TEXT
    );
  `);
};
